package com.logateprojekat.Car_Rental_Spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarRentalSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
